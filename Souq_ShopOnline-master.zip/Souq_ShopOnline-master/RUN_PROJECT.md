# Steps to run the application

- Start Server and MySql from Xampp.
- Import Database from SQL_Database to PhpMyAdmin [How to import](https://bit.ly/3d3ETWV).
- Create three folders inside Souq_Backend to store images.

  `mkdir storage_poster`

  `mkdir storage_product`

  `mkdir storage_user`
- Click the Souq_Backend folder and run `npm install` command to install server dependencies.
- To start the server, run `npm start` command.
- Open Android Studio and Run the project.
