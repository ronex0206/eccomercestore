package com.marwaeltayeb.souq.utils;

public interface OnNetworkListener {
    void onNetworkConnected();
    void onNetworkDisconnected();
}
