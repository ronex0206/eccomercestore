package com.marwaeltayeb.souq.utils;

public interface RequestCallback {
    void onCallBack();
}
